from .shapes import Shape, Circle, Triangle

__all__ = ["Shape", "Circle", "Triangle"]